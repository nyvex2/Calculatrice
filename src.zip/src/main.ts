// La logique de la calculatrice sera ajoutée ici.
